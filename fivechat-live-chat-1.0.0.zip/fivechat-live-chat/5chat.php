<?php
/**
 * Plugin Name:       5chat - Blazing fast live chat
 * Plugin URI:        https://5chat.io/integrations/wordpress
 * Description:       Easily integrate customer support live chat for your website.
 * Version:           1.0.0
 * Author:            5chat
 * Author URI:        https://5chat.io
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       fivechat
 * Domain Path:       /languages
 * Requires at least: 5.0
 * Tested up to:      6.5
 * Requires PHP:      7.4
 * Network:           false
 */

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define plugin constants
define( 'FIVECHAT_VERSION', '1.0.0' );
define( 'FIVECHAT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'FIVECHAT_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin activation hook
 */
function fivechat_activate() {
    // Add default options if they don't exist
    add_option( 'fivechat_website_token', '' );
}
register_activation_hook( __FILE__, 'fivechat_activate' );

/**
 * Plugin deactivation hook
 */
function fivechat_deactivate() {
    // Clean up any temporary data if needed
    // Note: We don't delete the settings here as user might reactivate
}
register_deactivation_hook( __FILE__, 'fivechat_deactivate' );

/**
 * Add the settings page to the WordPress admin menu.
 */
function fivechat_add_admin_menu() {
    add_options_page(
        '5chat Settings',
        '5chat',
        'manage_options',
        'fivechat-settings',
        'fivechat_options_page_html'
    );
}
add_action( 'admin_menu', 'fivechat_add_admin_menu' );

/**
 * Register settings, sections, and fields for the settings page.
 */
function fivechat_settings_init() {
    // Register the setting
    register_setting(
        'fivechat_settings_group',
        'fivechat_website_token',
        'fivechat_sanitize_token'
    );

    // Add a settings section
    add_settings_section(
        'fivechat_main_section',
        null, // No title needed for a single section
        null, // No description callback needed
        'fivechat-settings'
    );

    // Add the Website Token field
    add_settings_field(
        'fivechat_website_token_field',
        __( 'Website Token', 'fivechat' ),
        'fivechat_token_field_html',
        'fivechat-settings',
        'fivechat_main_section',
        [ 'label_for' => 'fivechat_website_token_id' ]
    );
}
add_action( 'admin_init', 'fivechat_settings_init' );

/**
 * Add AJAX actions for token validation
 */
add_action( 'wp_ajax_fivechat_validate_token', 'fivechat_validate_token_ajax' );

/**
 * AJAX handler for token validation
 */
function fivechat_validate_token_ajax() {
    // Verify nonce for security
    if ( ! wp_verify_nonce( $_POST['nonce'], 'fivechat_validate_token' ) ) {
        wp_die( 'Security check failed' );
    }
    
    // Check user permissions
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Insufficient permissions' );
    }
    
    $token = sanitize_text_field( $_POST['token'] );
    
    // Validate token format first
    if ( empty( $token ) ) {
        wp_send_json_error( array( 'message' => __( 'Token cannot be empty.', 'fivechat' ) ) );
    }
    
    if ( ! preg_match( '/^[a-zA-Z0-9_-]+$/', $token ) ) {
        wp_send_json_error( array( 'message' => __( 'Invalid token format. Use only letters, numbers, hyphens, and underscores.', 'fivechat' ) ) );
    }
    
    // Test the token with 5chat API
    $validation_result = fivechat_test_token( $token );
    
    if ( $validation_result['valid'] ) {
        wp_send_json_success( array( 
            'message' => __( 'Token is valid! Chat widget will load successfully.', 'fivechat' ),
            'token' => $token
        ) );
    } else {
        wp_send_json_error( array( 
            'message' => $validation_result['error']
        ) );
    }
}

/**
 * Test a token by making a request to 5chat widget endpoint
 */
function fivechat_test_token( $token ) {
    $widget_url = 'https://5chat.io/widget/' . $token;
    
    // Make HTTP request to validate token
    $response = wp_remote_get( $widget_url, array(
        'timeout' => 10,
        'headers' => array(
            'User-Agent' => 'WordPress 5chat Plugin Token Validator'
        )
    ) );
    
    // Check for request errors
    if ( is_wp_error( $response ) ) {
        return array(
            'valid' => false,
            'error' => __( 'Unable to connect to 5chat. Please check your internet connection and try again.', 'fivechat' )
        );
    }
    
    $response_code = wp_remote_retrieve_response_code( $response );
    
    // Check response status
    if ( $response_code === 200 ) {
        return array(
            'valid' => true,
            'error' => ''
        );
    } elseif ( $response_code === 404 ) {
        return array(
            'valid' => false,
            'error' => __( 'Invalid token. Please check your Website Token in your 5chat dashboard.', 'fivechat' )
        );
    } else {
        return array(
            'valid' => false,
            'error' => sprintf( 
                __( 'Token validation failed (HTTP %d). Please try again or contact 5chat support.', 'fivechat' ),
                $response_code
            )
        );
    }
}

/**
 * Render the HTML for the settings page.
 */
function fivechat_options_page_html() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <p><?php esc_html_e( 'Enter your 5chat Website Token below to enable the live chat widget.', 'fivechat' ); ?></p>
        
        <?php settings_errors( 'fivechat_website_token' ); ?>
        
        <form action="options.php" method="post" id="fivechat-settings-form">
            <?php
            settings_fields( 'fivechat_settings_group' );
            do_settings_sections( 'fivechat-settings' );
            ?>
            
            <div id="fivechat-validation-status" style="margin: 15px 0; display: none;">
                <div id="fivechat-validation-loading" class="notice notice-info" style="display: none;">
                    <p><span class="spinner is-active" style="float: none; margin: 0 5px 0 0;"></span><?php esc_html_e( 'Validating token...', 'fivechat' ); ?></p>
                </div>
                <div id="fivechat-validation-success" class="notice notice-success" style="display: none;">
                    <p><span class="dashicons dashicons-yes-alt" style="color: #46b450; margin-right: 5px;"></span><span id="fivechat-success-message"></span></p>
                </div>
                <div id="fivechat-validation-error" class="notice notice-error" style="display: none;">
                    <p><span class="dashicons dashicons-dismiss" style="color: #dc3232; margin-right: 5px;"></span><span id="fivechat-error-message"></span></p>
                </div>
            </div>
            
            <?php submit_button( __( 'Save Settings', 'fivechat' ) ); ?>
        </form>
        
        <div class="fivechat-help">
            <h3><?php esc_html_e( 'Need help?', 'fivechat' ); ?></h3>
            <p><?php esc_html_e( 'Visit your', 'fivechat' ); ?> <a href="https://5chat.io/dashboard" target="_blank"><?php esc_html_e( '5chat dashboard', 'fivechat' ); ?></a> <?php esc_html_e( 'to find your Website Token.', 'fivechat' ); ?></p>
        </div>
    </div>
    
    <style>
        #fivechat-validation-status .notice {
            margin: 0;
            padding: 8px 12px;
        }
        #fivechat-validation-status .dashicons {
            vertical-align: middle;
        }
        .fivechat-token-field-wrapper {
            position: relative;
        }
        .fivechat-validation-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 16px;
        }
        .fivechat-validation-icon.valid {
            color: #46b450;
        }
        .fivechat-validation-icon.invalid {
            color: #dc3232;
        }
        .fivechat-validation-icon.loading {
            color: #007cba;
            animation: fivechat-spin 1s linear infinite;
        }
        @keyframes fivechat-spin {
            0% { transform: translateY(-50%) rotate(0deg); }
            100% { transform: translateY(-50%) rotate(360deg); }
        }
    </style>
    
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            var validationTimeout;
            var lastValidatedToken = '';
            var isValidToken = false;
            
            // Token input field
            var $tokenField = $('#fivechat_website_token_id');
            var $form = $('#fivechat-settings-form');
            var $submitButton = $('#submit');
            
            // Validation status elements
            var $statusContainer = $('#fivechat-validation-status');
            var $loadingStatus = $('#fivechat-validation-loading');
            var $successStatus = $('#fivechat-validation-success');
            var $errorStatus = $('#fivechat-validation-error');
            var $successMessage = $('#fivechat-success-message');
            var $errorMessage = $('#fivechat-error-message');
            
            // Real-time validation on input
            $tokenField.on('input', function() {
                var token = $(this).val().trim();
                
                // Clear previous timeout
                clearTimeout(validationTimeout);
                
                // Hide all status messages
                hideAllStatus();
                
                // If empty, don't validate
                if (token === '') {
                    isValidToken = false;
                    return;
                }
                
                // If same as last validated, don't re-validate
                if (token === lastValidatedToken) {
                    return;
                }
                
                // Debounce validation (wait 800ms after user stops typing)
                validationTimeout = setTimeout(function() {
                    validateToken(token);
                }, 800);
            });
            
            // Prevent form submission if token is invalid
            $form.on('submit', function(e) {
                var token = $tokenField.val().trim();
                
                if (token !== '' && !isValidToken) {
                    e.preventDefault();
                    
                    // Show error message
                    showError('<?php esc_js_e( 'Please enter a valid Website Token before saving.', 'fivechat' ); ?>');
                    
                    return false;
                }
            });
            
            function validateToken(token) {
                // Show loading status
                showLoading();
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'fivechat_validate_token',
                        token: token,
                        nonce: '<?php echo wp_create_nonce( 'fivechat_validate_token' ); ?>'
                    },
                    success: function(response) {
                        lastValidatedToken = token;
                        
                        if (response.success) {
                            isValidToken = true;
                            showSuccess(response.data.message);
                        } else {
                            isValidToken = false;
                            showError(response.data.message);
                        }
                    },
                    error: function() {
                        isValidToken = false;
                        showError('<?php esc_js_e( 'Connection error. Please try again.', 'fivechat' ); ?>');
                    }
                });
            }
            
            function hideAllStatus() {
                $statusContainer.hide();
                $loadingStatus.hide();
                $successStatus.hide();
                $errorStatus.hide();
            }
            
            function showLoading() {
                $statusContainer.show();
                $loadingStatus.show();
                $successStatus.hide();
                $errorStatus.hide();
            }
            
            function showSuccess(message) {
                $successMessage.text(message);
                $statusContainer.show();
                $loadingStatus.hide();
                $successStatus.show();
                $errorStatus.hide();
            }
            
            function showError(message) {
                $errorMessage.text(message);
                $statusContainer.show();
                $loadingStatus.hide();
                $successStatus.hide();
                $errorStatus.show();
            }
            
            // Validate current token on page load if it exists
            var initialToken = $tokenField.val().trim();
            if (initialToken !== '') {
                validateToken(initialToken);
            }
        });
    </script>
    <?php
}

/**
 * Sanitization callback for the website token.
 */
function fivechat_sanitize_token( $input ) {
    // Trim whitespace and sanitize as a simple text field
    $sanitized = sanitize_text_field( trim( $input ) );
    
    // If empty, allow it (user can clear the token)
    if ( empty( $sanitized ) ) {
        return $sanitized;
    }
    
    // Basic format validation - token should be alphanumeric with possible hyphens/underscores
    if ( ! preg_match( '/^[a-zA-Z0-9_-]+$/', $sanitized ) ) {
        add_settings_error(
            'fivechat_website_token',
            'invalid_token_format',
            __( 'Invalid Website Token format. Please use only letters, numbers, hyphens, and underscores.', 'fivechat' ),
            'error'
        );
        // Return the previous value if validation fails
        return get_option( 'fivechat_website_token' );
    }
    
    // Validate token with 5chat API
    $validation_result = fivechat_test_token( $sanitized );
    
    if ( ! $validation_result['valid'] ) {
        add_settings_error(
            'fivechat_website_token',
            'invalid_token_api',
            sprintf( 
                __( 'Token validation failed: %s', 'fivechat' ),
                $validation_result['error']
            ),
            'error'
        );
        // Return the previous value if API validation fails
        return get_option( 'fivechat_website_token' );
    }
    
    // Token is valid, show success message
    add_settings_error(
        'fivechat_website_token',
        'token_validated',
        __( 'Website Token validated successfully! Your 5chat widget is now active.', 'fivechat' ),
        'success'
    );
    
    return $sanitized;
}

/**
 * Callback function to render the HTML for the Website Token input field.
 */
function fivechat_token_field_html() {
    $option_value = get_option( 'fivechat_website_token' );
    ?>
    <input type="text"
           id="fivechat_website_token_id"
           name="fivechat_website_token"
           value="<?php echo esc_attr( $option_value ); ?>"
           class="regular-text"
           placeholder="<?php esc_attr_e( 'Paste your Website Token here', 'fivechat' ); ?>">
    <p class="description">
        <?php esc_html_e( 'Find your Website Token in your 5chat dashboard.', 'fivechat' ); ?>
    </p>
    <?php
}

/**
 * Add the 5chat widget script to the website frontend head.
 */
function fivechat_add_widget_script() {
    $website_token = get_option( 'fivechat_website_token' );

    if ( ! empty( $website_token ) ) {
        $sanitized_token = esc_attr( $website_token );
        ?>
        <script src="https://5chat.io/widget/<?php echo $sanitized_token; ?>" async></script>
        <?php
    }
}
add_action( 'wp_head', 'fivechat_add_widget_script' );

/**
 * Display an admin notice if the 5chat token is not set or invalid.
 */
function fivechat_admin_notice_missing_token() {
    $website_token = get_option( 'fivechat_website_token' );
    global $pagenow;

    // Check capability and limit to relevant pages
    if ( ! current_user_can( 'manage_options' ) || 
         ! in_array( $pagenow, [ 'index.php', 'plugins.php', 'options-general.php' ] ) ) {
        return;
    }
    
    // Don't show on the settings page itself to avoid redundancy
    if ( $pagenow === 'options-general.php' && isset( $_GET['page'] ) && $_GET['page'] === 'fivechat-settings' ) {
        return;
    }

    // Show notice if token is empty or invalid
    $show_notice = false;
    $notice_message = '';
    
    if ( empty( $website_token ) ) {
        $show_notice = true;
        $notice_message = __( '<strong>5chat Live Chat is active, but no Website Token is configured.</strong>', 'fivechat' );
    } else {
        // Check if the current token is valid (cached check to avoid too many API calls)
        $token_check_cache = get_transient( 'fivechat_token_valid_' . md5( $website_token ) );
        
        if ( $token_check_cache === false ) {
            // Cache expired or doesn't exist, validate token
            $validation_result = fivechat_test_token( $website_token );
            
            // Cache result for 1 hour
            set_transient( 'fivechat_token_valid_' . md5( $website_token ), $validation_result['valid'] ? 'valid' : 'invalid', HOUR_IN_SECONDS );
            
            if ( ! $validation_result['valid'] ) {
                $show_notice = true;
                $notice_message = __( '<strong>5chat Live Chat token appears to be invalid.</strong>', 'fivechat' );
            }
        } elseif ( $token_check_cache === 'invalid' ) {
            $show_notice = true;
            $notice_message = __( '<strong>5chat Live Chat token appears to be invalid.</strong>', 'fivechat' );
        }
    }
    
    if ( $show_notice ) {
        $settings_page_url = admin_url( 'options-general.php?page=fivechat-settings' );
        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <?php
                echo wp_kses_post( $notice_message );
                printf(
                    ' ' . __( 'Please <a href="%s">update your settings</a> to enable the chat widget.', 'fivechat' ),
                    esc_url( $settings_page_url )
                );
                ?>
            </p>
        </div>
        <?php
    }
}
add_action( 'admin_notices', 'fivechat_admin_notice_missing_token' );

/**
 * Clear token validation cache when token is updated
 */
function fivechat_clear_token_cache( $old_value, $new_value ) {
    if ( $old_value !== $new_value ) {
        // Clear cache for old token
        if ( ! empty( $old_value ) ) {
            delete_transient( 'fivechat_token_valid_' . md5( $old_value ) );
        }
        // Clear cache for new token
        if ( ! empty( $new_value ) ) {
            delete_transient( 'fivechat_token_valid_' . md5( $new_value ) );
        }
    }
}
add_action( 'update_option_fivechat_website_token', 'fivechat_clear_token_cache', 10, 2 );

/**
 * Add a link to the settings page directly from the plugins list page.
 */
function fivechat_add_settings_link( $links ) {
    $settings_link = '<a href="' . admin_url( 'options-general.php?page=fivechat-settings' ) . '">' . __( 'Settings', 'fivechat' ) . '</a>';
    array_unshift( $links, $settings_link );
    return $links;
}
$plugin_basename = plugin_basename( __FILE__ );
add_filter( "plugin_action_links_{$plugin_basename}", 'fivechat_add_settings_link' );